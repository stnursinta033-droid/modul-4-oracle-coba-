public class StringConcat {
    public static void main(String[] args) {
        // dua object String yang terpisah
        String firstWord = "Belajar ";
        String secondWord = "Java";

        // digabungkan lalu ditetapkan ke object String ketiga yang bebas
        String combined = firstWord + secondWord;

        System.out.println(combined);
    }
}
