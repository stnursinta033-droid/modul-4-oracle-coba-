public class StudentDriver {
    public static void main(String[] args) {
        // membuat sebuah Student object
        Student lisa = new Student("Lisa", "Palombo", "123456789", "Active");

        // mencetak informasi object ke layar
        System.out.println("Student Name: " + lisa.getFName() + " " + lisa.getLName());
        System.out.println("Student ID: " + lisa.getStuId());
        System.out.println("Student Status: " + lisa.getStuStatus());
    }
}
