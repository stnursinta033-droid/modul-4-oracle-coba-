public class Student {
    // class variables
    private String fName;
    private String lName;
    private String stuId;
    private String stuStatus;

    // constructor
    public Student(String fName, String lName, String stuId, String stuStatus) {
        this.fName = fName;
        this.lName = lName;
        this.stuId = stuId;
        this.stuStatus = stuStatus;
    }

    // accessor methods
    public String getFName() {
        return fName;
    }

    public String getLName() {
        return lName;
    }

    public String getStuId() {
        return stuId;
    }

    public String getStuStatus() {
        return stuStatus;
    }
}
