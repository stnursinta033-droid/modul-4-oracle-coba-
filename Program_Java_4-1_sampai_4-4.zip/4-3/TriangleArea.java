import java.util.Scanner;

public class TriangleArea {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.print("Masukkan alas segitiga: ");
        double base = in.nextDouble();

        System.out.print("Masukkan tinggi segitiga: ");
        double height = in.nextDouble();

        // A = (1/2) x b x h  -> gunakan 0.5 agar tidak terjadi pembagian integer (1/2 = 0)
        double area = 0.5 * base * height;

        System.out.println("Luas segitiga = " + area);

        in.close();
    }
}
