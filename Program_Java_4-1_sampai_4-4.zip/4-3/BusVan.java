import java.util.Scanner;

public class BusVan {
    public static void main(String[] args) {
        final int KAPASITAS_BUS = 45;

        Scanner in = new Scanner(System.in);

        System.out.print("Masukkan jumlah orang yang mendaftar: ");
        int people = in.nextInt();

        // pembagian integer: hanya menghitung bus yang terisi penuh
        int buses = people / KAPASITAS_BUS;

        // sisa bagi (modulus): orang yang tidak muat satu bus penuh naik van
        int inVan = people % KAPASITAS_BUS;

        System.out.println("Jumlah bus yang diperlukan: " + buses);
        System.out.println("Jumlah orang yang naik van: " + inVan);

        in.close();
    }
}
