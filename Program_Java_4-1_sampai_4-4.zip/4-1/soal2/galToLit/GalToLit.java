package galToLit;

public class GalToLit {
    public static void main(String[] args) {
        // declare variables
        double gallons = 10;
        double liters = 0;

        // add your calculation here
        // 1 galon AS = 3,785 liter
        liters = gallons * 3.785;

        // output the result to user
        System.out.println(gallons + " gallons equals " + liters + " liters");
    }
}
