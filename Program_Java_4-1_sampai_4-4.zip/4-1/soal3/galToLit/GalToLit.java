package galToLit;

import java.util.Scanner;

public class GalToLit {
    public static void main(String[] args) {
        // membuat Scanner untuk membaca input dari pengguna
        Scanner in = new Scanner(System.in);

        // declare variables
        double gallons = 0;
        double liters = 0;

        // minta pengguna memasukkan jumlah galon
        System.out.print("Masukkan jumlah galon: ");
        gallons = in.nextDouble();

        // add your calculation here
        // 1 galon AS = 3,785 liter
        liters = gallons * 3.785;

        // output the result to user
        System.out.println(gallons + " gallons equals " + liters + " liters");

        in.close();
    }
}
